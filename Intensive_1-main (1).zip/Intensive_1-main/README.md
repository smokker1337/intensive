# Intensive_1

CD D:\Py_progekt\Intensive_1\parser\base & copy *.csv base.csv
